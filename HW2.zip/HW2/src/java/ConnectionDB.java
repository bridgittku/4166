
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bridgittku
 */
public class ConnectionDB {
    
    public ArrayList<Connection> connectionSet;
    
    //private method to setConnections using getters/setters from connections
    private void setConnections() {
        
        Connection sixthConnection = new Connection();
        sixthConnection.setHostName("Ben");
        sixthConnection.setConnectionID("15");
        sixthConnection.setConnectionName("Fancy Dinner Party");
        sixthConnection.setConnectionTopic("Cooking");
        sixthConnection.setDetails("We will be cooking fancy dishes, such as "
                + "mussels and Baked Alaska");
        sixthConnection.setDateTime("Friday, October 17th at 6pm");
        connectionSet.add(sixthConnection);
        
        Connection firstConnection = new Connection();
        firstConnection.setHostName("Bridgitt Ku");
        firstConnection.setConnectionID("52");
        firstConnection.setConnectionName("Italian Cooking Class");
        firstConnection.setConnectionTopic("Cooking");
        firstConnection.setDetails("We will be cooking fancy dishes, such as "
                + "mussels and Baked Alaska");
        firstConnection.setDateTime("Friday, October 17th at 6pm");
        connectionSet.add(firstConnection);
        
        Connection secondConnection = new Connection();
        secondConnection.setHostName("Jen");
        secondConnection.setConnectionID("20");
        secondConnection.setConnectionName("Meal Prep Class");
        secondConnection.setConnectionTopic("Cooking");
        secondConnection.setDetails("We will be giving tips on how to meal prep "
                + "for a busy week and making some easy meal prep recipes");
        secondConnection.setDateTime("Saturday, November 18th at 2pm");
        connectionSet.add(secondConnection);
        
        Connection thirdConnection = new Connection();
        thirdConnection.setHostName("Tim");
        thirdConnection.setConnectionID("25");
        thirdConnection.setConnectionName("Charlotte's cheap eats");
        thirdConnection.setConnectionTopic("Dining");
        thirdConnection.setDetails("We will be touring different restaurants in "
                + "Charlotte that offer dishes under $10");
        thirdConnection.setDateTime("Saturday, December 5th at 3pm");
        connectionSet.add(thirdConnection);
        
        Connection fourthConnection = new Connection();
        fourthConnection.setHostName("Jim");
        fourthConnection.setConnectionID("15");
        fourthConnection.setConnectionName("Uptown fine dining");
        fourthConnection.setConnectionTopic("Dining");
        fourthConnection.setDetails("We will be going to three of Charlotte's "
                + "finest establishments for appetizers, main course, and dessert");
        fourthConnection.setDateTime("Friday, October 7th at 7pm");
        connectionSet.add(fourthConnection);
        
        Connection fifthConnection = new Connection();
        fifthConnection.setHostName("Tom");
        fifthConnection.setConnectionID("30");
        fifthConnection.setConnectionName("Dessert tour of Charlotte");
        fifthConnection.setConnectionTopic("Dining");
        fifthConnection.setDetails("We will be going to Charlotte's best bakeries "
                + "and restaurants to sample their cookies, cakes, etc.");
        fifthConnection.setDateTime("Sunday, November 25th at 6pm");
        connectionSet.add(fifthConnection); 
    }
    
    public ArrayList<Connection> getConnections() {
        return connectionSet;
    }
    
    public Connection getConnection(String connectionID) {
        
        Connection rightConnection = new Connection();
        
        for (int i = 0; i < connectionSet.size(); i++) {
            if (connectionSet.get(i).getConnectionID() == connectionID) {
                rightConnection = connectionSet.get(i);
            }
        }
        return rightConnection;
    }
        
}
