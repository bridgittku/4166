/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author bridgittku
 */
public class ProfileControllerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ProfileControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ProfileControllerServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //Check session for current user using attribute theUser
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("theUser");
        UserDB userDatabase = new UserDB();
        //create UserProfile instance to hold user connections
        ArrayList<UserConnection> connections = new ArrayList<UserConnection>();
        UserProfile profile = new UserProfile(user, connections);
        //save user list of connections 
        connections = profile.getConnections();
        System.out.println("Connections are " + connections);
        session.setAttribute("viewConnections", connections);
        
        // if there is no user attribute
        if (user == null) {
            //create User javabean object
            User newUser = userDatabase.getUser(0);
            //add User javabean object to current session as theUser
            session.setAttribute("theUser", newUser);
            //load list of user connections
            //create UserProfile to hold user connections
            ArrayList<UserConnection> userConnections = new ArrayList<UserConnection>();
            UserProfile newProfile = new UserProfile(newUser, userConnections);
            newProfile.setUser(newUser);
            //save user list of connections
/*Check if this is right*/ //call getConnections() method in UserProfile class and add to current session
            userConnections = newProfile.getConnections();
            session.setAttribute("viewConnections", userConnections);
            /*Connection connection = new Connection();
            connection.setHostName("Alexis");
            connection.setConnectionID("8");
            connection.setConnectionName("Brewery tour");
            connection.setConnectionTopic("Dining");
            connection.setLocation("Heist");
            connection.setDetails("Try the best beer Charlotte has to offer!");
            connection.setDateTime("Tuesday, January 14th at 8pm");
            newProfile.addConnection(connection, "yes");*/
        } 
        
        if (user!=null) /*there is a user parameter and it is valid*/ {            
            //check http request for parameter called "action" or "task"
            String actionValue = request.getParameter("action");
            if (!"".equals(actionValue)) /* if parameter exists*/{      
                //validate that value is one of designated phrases
                if ("save".equals(actionValue)|| "updateProfile".equals(actionValue) || 
                    "updateRSVP".equals(actionValue) || "delete".equals(actionValue) ||
                    "signout".equals(actionValue)) {
                    
                    if ("signout".equals(actionValue)) /*action is "signout"*/{
                        //clear session and dispatch to home jsp view
                        session.invalidate();
                        getServletContext().getRequestDispatcher("/index.jsp").forward(request,response);
                    }
                    
                    //action is "save", "updateProfile", or "delete"
                    if ("save".equals(actionValue)|| "updateProfile".equals(actionValue) || "delete".equals(actionValue)){
                        //check http request for parameter called "viewConnections"
                        String connectionsValue = request.getParameter("viewConnections");
                        System.out.println(connectionsValue);
                        //return list of connection ids that appear in view
                        String[] viewConnectionsList = request.getParameterValues("viewConnections");
                        for (int i = 0; i < viewConnectionsList.length; i++) {
                            System.out.println("THESE ARE THE CONNECTIONS: " + viewConnectionsList[i]);
                        }
                        
                        if (!"".equals(connectionsValue)) /*if parameter exists*/{
                            //check http request for parameter "connectionID"
                            String idValue = request.getParameter("connectionID");
                            System.out.println("This is the connectionID:" + idValue);
                            //check that connectionID exists in view list
                            boolean inView = false;
                            for (int i = 0; i < viewConnectionsList.length; i++) {
                                if (idValue.equals(viewConnectionsList[i])) {
                                    //connectionID exists in view list
                                    inView = true;
                                } else {
                                    inView = false;
                                }   
                            }
                            
                            if (inView == false) /*connection is not in connection list*/ {
                                //dispatch to profile JSP view
                                getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                            } else /*connection exists in view list*/ {
                                //action is "save"
                                if ("save".equals(actionValue)) {
                                    //check http request for parameter "rsvp"
                                    String rsvpValue = request.getParameter("rsvp");
                                    System.out.println("RSVP is " + rsvpValue);
                                    //if parameter exists or value matches designated values
                                    if (rsvpValue.equals("yes") || rsvpValue.equals("no") || rsvpValue.equals("maybe")) {
                                        System.out.println("RSVP is valid");
                                        //check if connection from idValue exists in profile
                                        boolean idValueExists = false;
                                        int idValueIndex = 0;
                                        System.out.println("Connection is " + connections);
                                        for (int i = 0; i < connections.size(); i++) {
                                            if (idValue.equals(connections.get(i).getConnection().getConnectionID()) ) /*idValue exists in profile list*/{
                                                idValueExists = true;
                                                idValueIndex = i;
                                                System.out.println("Index is " + i);
                                            } else {
                                                idValueExists = false;
                                            }
                                        }
                                        
                                        if (idValueExists == true) /*connection exists in profile*/ {
                                            //update profile with new value for rsvp for that connection
                                            connections.get(idValueIndex).setRsvp(rsvpValue);
                                            System.out.println("The new rsvp is " + connections.get(idValueIndex).getRsvp());
                                            //update session object with updated user profile
    /*Problem here*/                        session.setAttribute("userProfile", profile);
                                            //dispatch to profile view
                                            getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                                        } else /*connection does not exist in profile*/ {
                                            //Create new UserConnection object using rsvp value                             
                                            ConnectionDB connectionDB = new ConnectionDB();
                                            Connection newConnection = connectionDB.getConnection(idValue);
                                            UserConnection newUserConnection = new UserConnection();
                                            newUserConnection.setConnection(newConnection);
                                            newUserConnection.setRsvp(rsvpValue);
                                            //add UserConnection object to UserProfile 
                                            profile.addConnection(newConnection,rsvpValue);
                                            System.out.println("The new connection's host name in list is " + profile.userConnectionList.get(1).getConnection().getHostName());
                                            //update session object with updated user profile
                                            session.setAttribute("userProfile", profile);
                                            //dispatch to profile JSP view
                                            getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                                        }
                                    } else /*parameter is not valid and value does not match designated values*/{
                                        System.out.println("RSVP is not valid");
                                        //dispatch to profile JSP view
                                        getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                 
                                    }
                                        
                                }
                                
                                if ("updateProfile".equals(actionValue)) /*action is "updateProfile"*/{
                                    //check if connection already exists in user profile
                                    boolean idValueExists = false;
                                        int idValueIndex = 0;
                                        for (int i = 0; i < connections.size(); i++) {
                                            if (idValue.equals(connections.get(i).getConnection().getConnectionID()) ) /*idValue exists in profile list*/{
                                                idValueExists = true;
                                                idValueIndex = i;
                                            } else {
                                                idValueExists = false;
                                            }
                                        }
                                        if (idValueExists == true) /*Connection exists in user profile*/{
                                            //get UserConnection object saved in user profile
                                            UserConnection newUserConnection = new UserConnection();
                                            for (int i = 0; i < connections.size(); i++) {
                                                if (idValue.equals(connections.get(i).getConnection().getConnectionID())){
                                                    newUserConnection = connections.get(i);
                                                }
                                            }
                                            //add UserConnection object to HTTP request as "theConnection"
                                            session.setAttribute("theConnection", newUserConnection);
                                            //dispatch to JSP view for connection.jsp
                                            getServletContext().getRequestDispatcher("/connection.jsp").forward(request, response);
                                            
                                        } else /*Connection does not exist*/{
                                            //dispatch to profile JSP view
                                            getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                                        }
                                }
                                if("delete".equals(actionValue)) /*Action is "delete"*/ {
                                    //check if connection already exists in user profile
                                    boolean idValueExists = false;
                                    int idValueIndex = 0;
                                    for (int i = 0; i < connections.size(); i++) {
                                        if (idValue.equals(connections.get(i).getConnection().getConnectionID()) ) /*idValue exists in profile list*/{
                                            idValueExists = true;
                                            idValueIndex = i;
                                        } else {
                                            idValueExists = false;
                                        }
                                    }
                                    if (idValueExists == true) /*Connection exists in user profile*/{
                                        //remove connection from user profile
                                        profile.removeConnection(connections.get(idValueIndex).getConnection());
                                        //update session object with updated user profile
                                        session.setAttribute("userProfile", profile);
                                        //dispatch to profile JSP view
                                        getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                                    } else /*Connection doesn't exist*/{
                                        //dispatch to profile JSP view
                                        getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                                    }
            
                                }
                                
                            }
                            
                        } else /*parameter does not exist*/{
                            //dispatch directly to profile JSP view
                            getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                        }
                    }
                } else /*Unknown value*/ {
                    //dispatch to profile JSP view
                    getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
                }
            } else /*No action parameter*/ {
                //dispatch to profile JSP view
                getServletContext().getRequestDispatcher("/savedConnections.jsp").forward(request, response);
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
