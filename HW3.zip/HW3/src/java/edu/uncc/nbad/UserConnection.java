/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.io.Serializable;
/**
 *
 * @author bridgittku
 */
public class UserConnection implements Serializable {
    
    private Connection connection;
    private String rsvp;
    
    public UserConnection() {
        
        connection = null;
        rsvp = "";
    }

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public String getRsvp() {
        return rsvp;
    }

    public void setRsvp(String rsvp) {
        this.rsvp = rsvp;
    }
    
}
