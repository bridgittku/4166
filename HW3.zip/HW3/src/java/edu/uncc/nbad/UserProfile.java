/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author bridgittku
 */
public class UserProfile implements Serializable {
    
    private User user;
    private List<UserConnection> userConnectionList;

    public UserProfile() {
        user = null;
        userConnectionList = null;
    }
    
    //getters and setters
    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<UserConnection> getConnection() {
        return userConnectionList;
    }

    public void setConnection(List<UserConnection> userConnection) {
        this.userConnectionList = userConnection;
    }
    
    public void addConnection(Connection connection, String rsvp) {
        
        boolean connectionExists = false;
        
        for (int i = 0; i < userConnectionList.size(); i++) {
            //check if UserConnection already exists for connection
            if (connection == userConnectionList.get(i).getConnection()) {
                //update existing connection
                userConnectionList.get(i).setRsvp(rsvp);
               
                //connection exists
                connectionExists = true;
            } 
        }
        
        if (connectionExists == false) {
            //add UserConnection for this connection to the user profile
            UserConnection newUserConnection = new UserConnection();
            newUserConnection.setConnection(connection);
            userConnectionList.add(newUserConnection);
        }
    }
    
    public void removeConnection(Connection connection) {
    
        for (int i = 0; i < userConnectionList.size(); i++) {
            //check for UserConnection associated with connection
            if (connection == userConnectionList.get(i).getConnection())  {
                //remove UserConnection associated with given connection
                userConnectionList.remove(i);
            }
        }
    }
    
    public void updateConnection(UserConnection userConnection, String rvsp) {
        //updates a Userconnection data (rsvp), sets RSVP to true
        userConnection.setRsvp(rvsp);
    }
    
    public List<UserConnection> getConnections() {
        return userConnectionList;
    }
    
    public void emptyProfile() {
        //clear entire profile contents
        for (int i = 0; i < userConnectionList.size(); i++) {
            userConnectionList.remove(i);
        }
    }
}
