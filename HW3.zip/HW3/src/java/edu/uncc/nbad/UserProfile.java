/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author bridgittku
 */
public class UserProfile implements Serializable {
    
    User user;
    ArrayList<UserConnection> userConnectionList;

    public UserProfile(User user, ArrayList<UserConnection> userConnectionList) {
        this.user = user;
        this.userConnectionList = userConnectionList;
        this.setFirstConnection();
    }
    
    //getters and setters
    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ArrayList<UserConnection> getConnection() {
        return this.userConnectionList;
    }

    public void setConnection(ArrayList<UserConnection> userConnection) {
        this.userConnectionList = userConnection;
    }
    
    public void addConnection(Connection connection, String rsvp) {
        
        boolean connectionExists = false;

        for (int i = 0; i < this.userConnectionList.size(); i++) {
            //check if UserConnection already exists for connection
            if (connection == this.userConnectionList.get(i).getConnection()) {
                //update existing connection
                this.userConnectionList.get(i).setRsvp(rsvp);
                //connection exists
                connectionExists = true;
            } 
        }
        
        if (connectionExists == false) {
            //add UserConnection for this connection to the user profile
            UserConnection newUserConnection = new UserConnection();
            newUserConnection.setConnection(connection);
            newUserConnection.setRsvp(rsvp);
            this.userConnectionList.add(newUserConnection);
        }
    }
    
    public void removeConnection(Connection connection) {
    
        for (int i = 0; i < this.userConnectionList.size(); i++) {
            //check for UserConnection associated with connection
            if (connection == this.userConnectionList.get(i).getConnection())  {
                //remove UserConnection associated with given connection
                this.userConnectionList.remove(i);
            }
        }
    }
    
    public void updateConnection(UserConnection userConnection, String rvsp) {
        //updates a Userconnection data (rsvp), sets RSVP to true
        userConnection.setRsvp(rvsp);
    }
    
    public ArrayList<UserConnection> getConnections() {
        return this.userConnectionList;
    }
    
    public void emptyProfile() {
        //clear entire profile contents
        for (int i = 0; i < this.userConnectionList.size(); i++) {
            this.userConnectionList.remove(i);
        }
    }
    
    public void setFirstConnection() {
        ConnectionDB connectionDatabase = new ConnectionDB();
        UserConnection userConnection = new UserConnection();
        Connection connection = connectionDatabase.getConnection("1");
        System.out.println("Connection from database is " + connection.getHostName());
        userConnection.setConnection(connection);
        userConnection.setRsvp("yes");
        System.out.println("Connection from user connection is " + userConnection.getConnection().getHostName());
        this.userConnectionList.add(userConnection);
    }
}
