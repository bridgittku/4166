package edu.uncc.nbad;


import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author bridgittku
 */
public class ConnectionDB {
    
    public ArrayList<Connection> connectionSet = new ArrayList<Connection>();
    
    public ConnectionDB() {
        this.setConnections();
    }
    
    //private method to setConnections using getters/setters from connections
    private void setConnections() {
        
        Connection firstConnection = new Connection();
        firstConnection.setHostName("Ben");
        firstConnection.setConnectionID("1");
        firstConnection.setConnectionName("Fancy Dinner Party");
        firstConnection.setConnectionTopic("Cooking");
        firstConnection.setDetails("We will be cooking fancy dishes, such as "
                + "mussels and Baked Alaska");
        firstConnection.setDateTime("Friday, October 17th at 6pm");
        firstConnection.setLocation("My House");
        this.connectionSet.add(firstConnection);
        
        Connection secondConnection = new Connection();
        secondConnection.setHostName("Bridgitt Ku");
        secondConnection.setConnectionID("2");
        secondConnection.setConnectionName("Italian Cooking Class");
        secondConnection.setConnectionTopic("Cooking");
        secondConnection.setDetails("Join us on a culinary adventure through Italy as we learn \n" +
"                    classic dishes with a chef from Naples, Italy. The meal will \n" +
"                    include handmade pasta, caprese salad, homemade focaccia, \n" +
"                    and panna cotta for dessert. Of course, no Italian meal would\n" +
"                    be complete without wine!");
        secondConnection.setDateTime("Saturday, October 18th at 6pm");
        secondConnection.setLocation("Salud! Cooking School");
        this.connectionSet.add(secondConnection);
        
        Connection thirdConnection = new Connection();
        thirdConnection.setHostName("Jen");
        thirdConnection.setConnectionID("3");
        thirdConnection.setConnectionName("Meal Prep Class");
        thirdConnection.setConnectionTopic("Cooking");
        thirdConnection.setDetails("We will be giving tips on how to meal prep "
                + "for a busy week and making some easy meal prep recipes");
        thirdConnection.setDateTime("Saturday, November 18th at 2pm");
        thirdConnection.setLocation("Salud! Cooking School");
        this.connectionSet.add(thirdConnection);
        
        Connection fourthConnection = new Connection();
        fourthConnection.setHostName("Tim");
        fourthConnection.setConnectionID("4");
        fourthConnection.setConnectionName("Charlotte's cheap eats");
        fourthConnection.setConnectionTopic("Dining");
        fourthConnection.setDetails("We will be touring different restaurants in "
                + "Charlotte that offer dishes under $10");
        fourthConnection.setDateTime("Saturday, December 5th at 3pm");
        fourthConnection.setLocation("Taco Restaurants");
        this.connectionSet.add(fourthConnection);
        
        Connection fifthConnection = new Connection();
        fifthConnection.setHostName("Jim");
        fifthConnection.setConnectionID("5");
        fifthConnection.setConnectionName("Uptown fine dining");
        fifthConnection.setConnectionTopic("Dining");
        fifthConnection.setDetails("We will be going to three of Charlotte's "
                + "finest establishments for appetizers, main course, and dessert");
        fifthConnection.setDateTime("Friday, October 7th at 7pm");
        fifthConnection.setLocation("Mama Ricotta's");
        this.connectionSet.add(fifthConnection);
        
        Connection sixthConnection = new Connection();
        sixthConnection.setHostName("Tom");
        sixthConnection.setConnectionID("6");
        sixthConnection.setConnectionName("Dessert tour of Charlotte");
        sixthConnection.setConnectionTopic("Dining");
        sixthConnection.setDetails("We will be going to Charlotte's best bakeries "
                + "and restaurants to sample their cookies, cakes, etc.");
        sixthConnection.setDateTime("Sunday, November 25th at 6pm");
        sixthConnection.setLocation("Amelie's");
        this.connectionSet.add(sixthConnection); 
        
        Connection seventhConnection = new Connection();
        seventhConnection.setHostName("Lennon");
        seventhConnection.setConnectionID("7");
        seventhConnection.setConnectionName("Taco tour of Charlotte");
        seventhConnection.setConnectionTopic("Dining");
        seventhConnection.setDetails("We will be going to Charlotte's best taco spots");
        seventhConnection.setDateTime("Monday, December 22nd at 6pm");
        seventhConnection.setLocation("Noda");
        this.connectionSet.add(seventhConnection); 
        
    }
    
    public void printConnections() {
        System.out.println("Printing connections here");
        for (int i = 0; i < this.connectionSet.size();i++) {
            System.out.println(this.connectionSet.get(i));
        }
    }
    
    public ArrayList<Connection> getConnections() {
        setConnections();
        printConnections();
        return this.connectionSet;
    }
    
    public Connection getConnection(String connectionID) {
        
        setConnections();
        Connection rightConnection = new Connection();
        
        for (int i = 0; i < this.connectionSet.size(); i++) {
            if (this.connectionSet.get(i).getConnectionID().equals(connectionID)) {
                rightConnection = this.connectionSet.get(i);
            }
        }
        return rightConnection;
    }
    
    
}
