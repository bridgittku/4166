/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.util.ArrayList;

/**
 *
 * @author bridgittku
 */
public class UserDB {
    
    public ArrayList<User> userSet = new ArrayList<User>();
    
    public UserDB() {
        this.setUsers();
    }
    
    //hardcode three users 
    private void setUsers() {
        
        User firstUser = new User();
        firstUser.setUserID("1");
        firstUser.setFirstName("Ron");
        firstUser.setLastName("Swanson");
        firstUser.setEmail("rswanson@gmail.com");
        userSet.add(firstUser);
        
        User secondUser = new User();
        secondUser.setUserID("2");
        secondUser.setFirstName("Leslie");
        secondUser.setLastName("Knope");
        secondUser.setEmail("lknope@gmail.com");
        userSet.add(secondUser);
        
        User thirdUser = new User();
        thirdUser.setUserID("3");
        thirdUser.setFirstName("Andy");
        thirdUser.setLastName("Dwyer");
        thirdUser.setEmail("adwyer@gmail.com");
        userSet.add(thirdUser);
    }
    
    //gets particular user in hardcoded database
    public User getUser(int index) {
        return userSet.get(index);
       
    }
    
    //return set of all users in hardcoded database
    public ArrayList<User> getUsers() {
        return userSet;
    }
}
