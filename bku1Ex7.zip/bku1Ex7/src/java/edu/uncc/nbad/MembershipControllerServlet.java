/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.nbad;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author bridgittku
 */
public class MembershipControllerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MembershipControllerServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Set response content type
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MembershipControllerServlet at " + request.getContextPath() + "</h1>");
            String value = request.getParameter("task");
            if (value.equals("signup")) {
                getServletContext().getRequestDispatcher("/signup.jsp").forward(request,response);
            } else {
                out.println("<p>Error! The task parameter is required, only signup value is valid.</p>");
            } 
            out.println("</body>");
            out.println("</html>");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        //read form fields 
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String password = request.getParameter("passid");
        String address = request.getParameter("address");
        String country = request.getParameter("country");
        String zip = request.getParameter("zip");
        String email = request.getParameter("email");
        String gender = request.getParameter("gender");
        String language = request.getParameter("langs");
        String description = request.getParameter("about");
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet MembershipControllerServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Registration Info</h1>");
            String value = request.getParameter("task");
            if (value.equals("signup")) {
                if (name != null && username != null && password != null && address != null &&
                        country != null && zip != null && email != null && gender != null &&
                        language != null && description != null) {
                    
                    //Create UserInfo object
                    UserInfo user = new UserInfo();
                    
                    //Populate UserInfo object with submitted form data
                    user.setName(name);
                    user.setUsername(username);
                    user.setPassword(password);
                    user.setAddress(address);
                    user.setCountry(country);
                    user.setZip(zip);
                    user.setEmail(email);
                    user.setGender(gender);
                    user.setLangs(language);
                    user.setDesc(description);
                    
                    //setAttribute method
                    request.setAttribute("userInfo", user);
        
                    //forward request to profile.jsp
                    getServletContext().getRequestDispatcher("/profile.jsp").forward(request,response);
        
                    
                } else {
                    ArrayList<String> errors = new ArrayList<String>();
                    
                    if (name == null) {
                        errors.add("name");
                    }
                    if (username == null) {
                        errors.add("username");
                    }
                    if (password == null) {
                        errors.add("password");
                    }
                    if (address == null) {
                        errors.add("address");
                    }
                    if (country == null) {
                        errors.add("country");
                    }
                    if (zip == null) {
                        errors.add("zip");
                    }
                    if (email == null) {
                        errors.add("email");
                    }
                    if (gender == null) {
                        errors.add("gender");
                    }
                    if (language == null) {
                        errors.add("language");
                    }
                    if (description == null) {
                        errors.add("description");
                    }
                    out.println("<p> Please fill in the missing values:" + errors + "</p>");
                    getServletContext().getRequestDispatcher("/signup.jsp").forward(request,response);
                }
            } else {
                out.println("<p>Error! The task parameter is required, only signup value is valid.</p>");
            } 
            out.println("</body>");
            out.println("</html>");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
